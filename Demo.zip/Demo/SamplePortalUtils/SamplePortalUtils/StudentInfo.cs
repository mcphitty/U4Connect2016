﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamplePortalUtils
{
    public class StudentInfo
    {
        /// <summary>
        /// Constructor for class StudentInfo
        /// </summary>
        public StudentInfo()
        {
            //An explicit constructor is requires for COM-accessibility, the Server.CreateObject call will use this.
        }

        /// <summary>
        /// This method returns the Campus ID for the specified student in the specified term.
        /// </summary>
        /// <param name="StudentUID">The unique identifier for a student</param>
        /// <param name="TermCalendarID">The ID of the term to look up</param>
        /// <returns>The student's campus ID for the given term</returns>
        public int GetCampusID(int StudentUID, int TermCalendarID)
        {
            int CampusID;

            using (SqlConnection conn = new SqlConnection("Data Source=CAMS-SQL;Initial Catalog=CAMS_Enterprise;Persist Security Info=True;User ID=U4C2016;Password=Unit4Demo;Connection Timeout=60;MultipleActiveResultSets=true"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT CampusID FROM CAMS_StudentStatus_View WHERE StudentUID = @StudentUID AND TermCalendarID = @TermCalendarID", conn))
                {
                    cmd.Parameters.AddWithValue("@StudentUID", StudentUID);
                    cmd.Parameters.AddWithValue("@TermCalendarID", TermCalendarID);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        using (DataSet ds = new DataSet())
                        {
                            da.Fill(ds);
                            using (DataTable dt = ds.Tables[0])
                            {
                                CampusID = (int)dt.Rows[0]["CampusID"];
                            }
                        }
                    }
                }
                conn.Close();
            }

            return CampusID;
        }

        public string GetCampusName(int StudentUID, int TermCalendarID)
        {
            string Campus;

            using (SqlConnection conn = new SqlConnection("Data Source=CAMS-SQL;Initial Catalog=CAMS_Enterprise;Persist Security Info=True;User ID=U4C2016;Password=Unit4Demo;Connection Timeout=60;MultipleActiveResultSets=true"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT Campus FROM CAMS_StudentStatus_View WHERE StudentUID = @StudentUID AND TermCalendarID = @TermCalendarID", conn))
                {
                    cmd.Parameters.AddWithValue("@StudentUID", StudentUID);
                    cmd.Parameters.AddWithValue("@TermCalendarID", TermCalendarID);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        using (DataSet ds = new DataSet())
                        {
                            da.Fill(ds);
                            using (DataTable dt = ds.Tables[0])
                            {
                                Campus = dt.Rows[0]["Campus"].ToString();
                            }
                        }
                    }
                }
                conn.Close();
            }

            return Campus;
        }

    }
}
